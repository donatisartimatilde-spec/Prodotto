/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package testprodotto;

import java.util.Objects;

/**
 *
 * @author utente
 */
public class Prodotto {
    
// Attributi privati 
    private String nome; 
    private double peso;
    private double prezzo;
    private int numeroPezzi;

    /**
     * 
     * @param nome il nome del prodotto.
     * @param peso il peso in kg del singolo prodotto.
     * @param prezzo il presso in euro del singolo prodotto.
     * @param numeroPezzi il numero dei pezzi disponibili del prodotto. (deve essere maggiore di 0)
     */
    public Prodotto(String nome, double peso, double prezzo, int numeroPezzi) {
        this.nome = nome;
        this.peso = Math.max(0.0, peso);
        this.prezzo = Math.max(0.0, prezzo);
        this.numeroPezzi = Math.max(0, numeroPezzi);
    }

    // Metodi getter

    public String getNome() {
        return nome;
    }

    public double getPeso() {
        return peso;
    }

    public double getPrezzo() {
        return prezzo;
    }

    public int getNumeroPezzi() {
        return numeroPezzi;
    }

    // Metodo Setter

    /**
     * Modifica il prezzo del prodotto.
     *
     * @param nuovoPrezzo Il nuovo prezzo in euro.
     */
    public void setPrezzo(double nuovoPrezzo) {
        if (nuovoPrezzo >= 0) {
            this.prezzo = nuovoPrezzo;
        }
    }

  

    /**
     * Vende una determinata quantità di prodotto scalando i pezzi disponibili.
     *
     * @param quantita Numero di pezzi da vendere.
     * @return true se la vendita è andata a buon fine, false se i pezzi non sono sufficienti o la quantità non è valida.
     */
    public boolean vendiProdotto(int quantita) {
        if (quantita > 0 && quantita <= numeroPezzi) {
            numeroPezzi -= quantita;
            return true;
        }
        return false;
    }

    /**
     * Incrementa la quantità di pezzi disponibili in magazzino.
     *
     * @param quantita Numero di pezzi da aggiungere.
     * @return true se il rifornimento è andato a buon fine, false se la quantità non è valida.
     */
    public boolean rifornisci(int quantita) {
        if (quantita > 0) {
            numeroPezzi += quantita;
            return true;
        }
        return false;
    }

    /**
     * Confronta il prodotto attuale con un altro prodotto per verificare se hanno lo stesso nome e peso.
     *
     * @param altro Il prodotto da confrontare.
     * @return true se hanno stesso nome e peso, altrimenti false.
     */
    public boolean confronta(Prodotto altro) {
        if (altro == null) {
            return false;
        }
        return this.peso == altro.peso && Objects.equals(this.nome, altro.nome);
    }

    // metodi di confronto 

    @Override
    public boolean equals(Object obj) {
        if (this == obj) return true;
        if (obj == null || getClass() != obj.getClass()) return false;
        Prodotto altro = (Prodotto) obj;
        return Double.compare(altro.peso, peso) == 0 && Objects.equals(nome, altro.nome);
    }

    @Override
    public int hashCode() {
        int hash = 7;
        hash = 53 * hash + Objects.hashCode(this.nome);
        hash = 53 * hash + (int) (Double.doubleToLongBits(this.peso) ^ (Double.doubleToLongBits(this.peso) >>> 32));
        hash = 53 * hash + (int) (Double.doubleToLongBits(this.prezzo) ^ (Double.doubleToLongBits(this.prezzo) >>> 32));
        hash = 53 * hash + this.numeroPezzi;
        return hash;
    }

    @Override
    public String toString() {
        return "Prodotto: " + nome + " | Peso: " + peso + " kg" + " | Prezzo: " + prezzo + " euro" + " | Pezzi Disponibili: " + numeroPezzi; 
    }

}
   
