/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Main.java to edit this template
 */
package testprodotto;

/**
 * Classe di test per verificare le funzionalità della classe Prodotto. 
 * @author utente
 */
public class TestProdotto {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
        // TODO code application logic here
      
        // Creazione oggetti Prodotto
        Prodotto p1 = new Prodotto("Pasta 500g", 0.5, 1.20, 10);
        Prodotto p2 = new Prodotto("Pasta 500g", 0.5, 1.50, 5);
        Prodotto p3 = new Prodotto("Riso 1kg", 1.0, 2.80, 20);

        System.out.println("\n Stato iniziale dei prodotti ");
        System.out.println(p1);
        System.out.println(p2);
        System.out.println(p3);

        // Test vendita prodotto
        System.out.println("\n Test vendita prodotto ");
        int quantitaDaVendere = 3;
        if (p1.vendiProdotto(quantitaDaVendere)) {
            System.out.println("Vendita di " + quantitaDaVendere + " pezzi effettuata con successo");
        } else {
            System.out.println("Errore: pezzi insufficienti o quantità non valida.");
        }
        System.out.println(p1);

        // Test vendita errata 
        System.out.println("\nTentativo vendita di 50 pezzi:");
        if (!p1.vendiProdotto(50)) {
            System.out.println("Errore: impossibile vendere 50 pezzi, disponibilita insufficiente");
        }

        // Test rifornimento
        System.out.println("\n Test rifornimento ");
        int quantitaRifornimento = 15;
        if (p1.rifornisci(quantitaRifornimento)) {
            System.out.println("Rifornimento di " + quantitaRifornimento + " pezzi eseguito con successo");
        } else {
            System.out.println("Errore: quantità di rifornimento non valida.");
        }
        System.out.println(p1);

        // Test modifica prezzo 
        System.out.println("\n Test cambio prezzo ");
        System.out.println("Prezzo vecchio: " + p1.getPrezzo() + " euro");
        p1.setPrezzo(1.35);
        System.out.println("Prezzo aggiornato: " + p1.getPrezzo() + " euro");

        // Test metodo confronta
        System.out.println("\n Test confronto tra prodotti ");
        if (p1.confronta(p2)) {
            System.out.println("p1 e p2 sono lo stesso prodotto (stesso nome e stesso peso).");
        } else {
            System.out.println("p1 e p2 sono prodotti diversi.");
        }

        if (p1.confronta(p3)) {
            System.out.println("p1 e p3 sono lo stesso prodotto.");
        } else {
            System.out.println("p1 e p3 sono prodotti diversi.");
        }
    }
}

    